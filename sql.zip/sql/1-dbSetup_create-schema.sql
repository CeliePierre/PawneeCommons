-- Creates the database
-- Named Pawnee Commons as a reference to the TV show Parks and Recreation
CREATE SCHEMA `PawneeCommons` ;
