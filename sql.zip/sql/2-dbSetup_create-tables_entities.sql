-- Creates the Character table
-- Renamed "charactr" due to reserved keyword of character
drop table if exists charactr;
create table charactr
(
	-- Character's ID number
    cID int(4),
    -- Character's name
    cFirstName varchar(50),
    cLastName varchar(50),
    primary key (cID)
);

-- Created the Person table
drop table if exists person;
create table person
(
	-- Person's ID number
    pID int(4),
    -- Peron's name
    pFirstName varchar(50),
    pLastName varchar(50),
    primary key (pID)
);

-- Creates the Episode table
drop table if exists episode;
create table episode
(
	-- Episode's ID number
    -- Format: s01e01 (season 01, episode 01)
    eID varchar(6), 
    -- Season number
    season int(2) not null,
    -- Episode number within the season
    episode int(2) not null,
    -- Episode title
    title varchar(60) not null,
    -- Episode's original air date
    airDate date,
    -- Episode description
    descript varchar(300),
    primary key (eID)
);

-- Creates the Transcripts table
drop table if exists transcripts;
create table transcripts
(
	-- Line ID number
    -- Format: s01e01-001 (season 01, episode 01, line 001)
    lID varchar(10), 
    lineNum int(3) not null,
    -- Dialogue in the transcript
    dialogue varchar(16000),
    primary key (lID)
);

-- Creates the Viewers table
drop table if exists viewers;
create table viewers
(
	-- Viewer ID number
    -- Format: s01e01 (season 01, episode 01)
    vID varchar(6), 
    -- Ratings, votes, # of viewers
    rating numeric(2,1),
    votes int(4),
    viewers int(7),
    primary key (vID)
);
