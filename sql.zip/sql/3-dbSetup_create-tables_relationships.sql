-- Creates the Plays table
-- Links the charactr to the Person (actor)
drop table if exists plays;
create table plays
(
    cID int(4),
    cFirstName varchar(50),
    cLastName varchar(50),
	pID int(4),
    pFirstName varchar(50),
    pLastName varchar(50),
    foreign key (cID) references charactr (cID),
    foreign key (pID) references person (pID)
);

-- Creates the Works table
-- Links the Person to the Episode they worked on
drop table if exists works;
create table works
(
    pID int(4),
    eID varchar(6),
    job varchar(20) not null,
    foreign key (pID) references person (pID)
);

-- Creates the Views table
-- Links the Viewer to the Episode
drop table if exists views;
create table views
(
	vID varchar(6),
    eID varchar(6),
    foreign key (vID) references viewers (vID),
    foreign key (eID) references episode (eID)
);

-- Creates the Scripts table
-- Links the Episode to the Transcript
drop table if exists scripts;
create table scripts
(
    eID varchar(6),
    lID varchar(10),
    foreign key (eID) references episode (eID),
    foreign key (lID) references transcripts (lID)
);

-- Creates the Says table
-- Links the charactr to the Line they said and the Episode they said it in
drop table if exists says;
create table says
(
    lID varchar(10),
    eID varchar(6),
    cID int(4),
    cName varchar(100),
    foreign key (lID) references transcripts (lID),
    foreign key (cID) references charactr (cID),
    foreign key (eID) references episode (eID),
    foreign key (lID) references transcripts (lID)
);
