-- Updates the Plays table based on names and IDs from the People table
-- NOTE: This may be slow to run and might time out, but it will update
update plays as Y
join person as P on (P.pFirstName = Y.pFirstName and P.pLastName = Y.pLastName)
set Y.pID = P.pID;

-- Updates the Says table based on names and IDs from the Charactr table
-- NOTE: This may be slow to run and might time out, but it will update
update says as S
join charactr as C on S.cName = CONCAT(C.cFirstName, ' ', C.cLastName)
set S.cID = C.cID;
