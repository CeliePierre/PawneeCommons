/* Character
	● Search by: ID and/or name (character)
	● Returns: Character data (ID, full name), Person data (based on Plays relation), Transcript
	data (based on Says relation), Episode data (based on Says in relation)
*/
DELIMITER //
-- drop procedure if exists basic_character;
create procedure basic_character
(
    in cID_in int(4),
    in firstName_in varchar(50),
    in lastName_in varchar(50)
)
begin
	select C.cID, C.cFirstName, C.cLastName, E.title as "appears in", count(S.lID) as "# of lines"
	from (charactr as C join says as S on C.cID = S.cID) join episode as E on S.eID = E.eID
	where (C.cFirstName = firstName_in and C.cLastName = lastName_in) or (C.cID = cID_in)
	group by C.cID, C.cFirstName, C.cLastName, E.title;
end //

/* Person
	● Search by: ID, name (person), and/or job title
	● Returns: Person data (ID, full name, job title), Episode data (based on Works On relation)
*/
DELIMITER //
-- drop procedure if exists basic_person;
create procedure basic_person
(
    in pID_in int(4),
    in firstName_in varchar(50),
    in lastName_in varchar(50),
    in job_in varchar(20)
)
begin
	select P.pID, P.pFirstName, P.pLastName, W.job, E.title as "worked on"
	from person as P, (works as W join episode as E on W.eID = E.eID)
	where ((P.pFirstName = firstName_in and P.pLastName = lastName_in) or (P.pID = pID_in)) and (W.job = job_in)
	group by P.pID, P.pFirstName, P.pLastName, W.job, E.title;
end //

/* Episode
	● Search by: title, season, episode number, ID, and/or air date
	● Returns: Episode data (ID, episode number, season, title, description, original air date,
	number of US viewers), Transcript (based on Has relation), Viewers (based on Views
	relation)
*/
DELIMITER //
-- drop procedure if exists basic_episode;
create procedure basic_episode
(
    in title_in varchar(60),
    in season_in int(2),
    in episode_in int(3),
    in eID_in varchar(6),
    in airDate_in date
)
begin
	select E.eID, E.season, E.episode, E.title, E.airDate, E.descript, V.rating, V.viewers
	from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID
	where (E.title = title_in) or (E.season = season_in and E.episode = episode_in) or (E.eID = eID_in) or (E.airDate = airDate_in)
	group by E.eID, E.season, E.episode, E.title, E.airDate, E.descript, V.rating, V.viewers;
end //

/* Transcript
	● Search by: episode, character, and/or dialogue length
	● Returns: Transcript data (line ID, dialogue), Character (based on Says relation)
*/
DELIMITER //
-- drop procedure if exists basic_transcript;
create procedure basic_transcript
(
    in title_in varchar(60),
    in firstName_in varchar(50), 
    in lastName_in varchar(50), 
    in dialogue_in int(5)
)
begin
	select E.eID, E.season, E.episode, E.title, C.cFirstName, C.cLastName, T.dialogue
	from ((transcripts as T join says as S on T.lID = S.lID) join episode as E on E.eID = S.eID) join charactr as C on C.cID = S.cID
	where (E.title = title_in) or (C.cFirstName = firstName_in and C.cLastName = lastName_in) or (length(T.dialogue) >= dialogue_in)
	group by E.eID, E.season, E.episode, E.title, C.cFirstName, C.cLastName, T.dialogue;
end //

/*
Viewers
	● Search by: Rating, amount of votes, and/or viewers
	● Returns: Viewers data (ID, rating, amount of votes, viewers), Episode data (based on
	Views relation)
*/
DELIMITER //
-- drop procedure if exists basic_viewers;
create procedure basic_viewers
(
    in rating_in decimal(2,1),
    in votes_in int(5), 
    in viewers_in int(10)
)
begin
	select E.eID, E.season, E.episode, E.title, E.airDate, V.rating, V.votes, V.viewers
	from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID
	where V.rating >= rating_in and V.votes >= votes_in and V.viewers >= viewers_in
	group by E.eID, E.season, E.episode, E.title, E.airDate, V.rating, V.votes, V.viewers;
end //
