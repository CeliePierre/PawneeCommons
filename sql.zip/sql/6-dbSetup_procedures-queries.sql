-- People who have appeared in the show and also have either written or directed
DELIMITER //
drop procedure if exists q_actor_creator;
create procedure q_actor_creator()
begin
	select P.pID, P.pFirstName, P.pLastName, count(distinct W.job) as "# of jobs"
	from (person as P join works as W on P.pID = W.pID)
	group by pID
	having count(distinct W.job) >= 2 and count(distinct W.job = "Cast") > 1;
end //

-- Most popular characters (appears in most episodes)
DELIMITER //
drop procedure if exists q_popular_characters;
create procedure q_popular_characters()
begin
	select rank() over (order by count(distinct eID) desc) as "rank", 
		cFirstName, cLastName, count(distinct eID) as "total episodes"
	from charactr
	join says on charactr.cID = says.cID
	group by cFirstName, cLastName;
end //

-- Main cast (appear in more than 30 episodes)
DELIMITER //
drop procedure if exists q_main_cast;
create procedure q_main_cast()
begin
	select rank() over (order by count(distinct eID) desc) as "rank", 
		cFirstName, cLastName, count(distinct eID) as "total episodes"
	from charactr
	join says on charactr.cID = says.cID
	group by cFirstName, cLastName
	having count(distinct eID) >= 30;
end //

-- Recurring guest stars (appear in 2-29 episodes)
DELIMITER //
drop procedure if exists q_guest_stars;
create procedure q_guest_stars()
begin
	select rank() over (order by count(distinct eID) desc) as "rank", 
		cFirstName, cLastName, count(distinct eID) as "total episodes"
	from charactr
	join says on charactr.cID = says.cID
	group by cFirstName, cLastName
	having (count(distinct eID) < 30) and (count(distinct eID) > 1);
end //

-- Best season (most views, highest rated, ranked based on rating then total views)
DELIMITER //
drop procedure if exists q_best_seasons;
create procedure q_best_seasons()
begin
	select rank() over (order by avg(V.rating) desc, avg(V.viewers) desc) as "rank", 
		E.season, avg(V.rating) as "avg rating", sum(V.viewers) as "total viewers"
	from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID
	group by E.season;
end //

-- Best episodes (most views, highest rated, ranked based on rating then viewers)
DELIMITER //
drop procedure if exists q_best_episodes;
create procedure q_best_episodes()
begin
	select rank() over (order by V.rating desc, V.viewers desc) as "rank", 
		E.eID, E.season, E.episode, E.title, E.airDate, V.rating, V.viewers
	from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID;
end //

-- Character with the most lines, ranked
DELIMITER //
drop procedure if exists q_most_lines;
create procedure q_most_lines()
begin
	select rank() over (order by count(distinct lID) desc) as "rank", 
		cFirstName, cLastName, count(distinct lID) as "total lines"
	from charactr
	join says on charactr.cID = says.cID
	group by cFirstName, cLastName;
end //

-- Additional functionality
DELIMITER //
drop procedure if exists t_update_job;
create procedure t_update_job
(
    in job_in varchar(20),
    in pID_in int(4),
    in eID_in varchar(6)
)
begin

-- Start the transaction
START TRANSACTION;

-- Update operation within the transaction
UPDATE PawneeCommons.works
SET job = job_in -- This value violates the allowed job titles
WHERE pID = pID_in AND eID = eID_in;

-- Set the allowed job titles
SET @allowed_job_titles := 'Cast,written_by,directed_by';

-- Check the integrity constraint
SET @job_check := FIND_IN_SET(job_in, @allowed_job_titles COLLATE utf8mb4_general_ci);

-- Variable to store the result of the condition
SET @rollback_required := 0;

-- Check the condition and set the variable accordingly
SELECT IF(@job_check = 0, @rollback_required := 1, @rollback_required);

-- Rollback or commit based on the condition
SELECT CASE
    WHEN @rollback_required = 1 THEN
        -- Rollback the transaction if the constraint is violated
        'Transaction Rolled Back'
    ELSE
        -- Commit the transaction if the constraint is satisfied
        'Transaction Committed'
END AS Result;

end //
