/*
Procedures will allow for user input.
Procedures based on OR input. Names are AND (first AND last names).

Below is testing for Stored Procedures
Uncomment 1 at a time to test
Data can be changed for testing
*/

-- call basic_character(1, 'leslie', 'knope')
-- call basic_episode('pilot', 1, 1, 's1e01', '2009-04-09')
-- call basic_person(1, 'amy', 'poehler', 'cast')
-- call basic_transcript('pilot', 'leslie', 'knope', '1')
-- call basic_viewers(9, 1000, 100000)
