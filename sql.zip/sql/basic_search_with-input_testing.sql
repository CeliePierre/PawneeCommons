/*
Procedures will allow for user input.
Procedures based on OR input. Names are AND (first AND last names).

Below is testing for Stored Procedures
Uncomment 1 at a time to test
Data can be changed for testing
*/

-- call basic_character(0, 'leslie', '')
-- call basic_episode('pilot', 1, 1, 's1e01', '2009-04-09')
-- call basic_person(0, '', '', '')
-- call basic_transcript('pilot', 'leslie', 'knope', '1')
-- call basic_viewers(9, 0, 0)

-- call q_best_seasons()

-- job_in, pID_in, eID_in

call t_update_job('testing', 999, 's1e01')