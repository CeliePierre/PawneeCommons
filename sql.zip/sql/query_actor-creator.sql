-- People who have appeared in the show and also have either written or directed

select P.pID, P.pFirstName, P.pLastName, count(distinct W.job) as "# of jobs"
from (person as P join works as W on P.pID = W.pID)
group by pID
having count(distinct W.job) >= 2 and count(distinct W.job = "Cast") > 1
