-- Best episodes (most views, highest rated, ranked based on rating then viewers)

select rank() over (order by V.rating desc, V.viewers desc) as "rank", 
	E.eID, E.season, E.episode, E.title, E.airDate, V.rating, V.viewers
from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID