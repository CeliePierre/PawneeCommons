-- Best season (most views, highest rated, ranked based on rating then total views)

select rank() over (order by avg(V.rating) desc, avg(V.viewers) desc) as "rank", 
	E.season, avg(V.rating) as "avg rating", sum(V.viewers) as "total viewers"
from (episode as E join views as Vw on E.eID = Vw.eID) join viewers as V on Vw.vID = V.vID
group by E.season