-- Main cast (appear in more than 30 episodes)

select rank() over (order by count(distinct eID) desc) as "rank", 
	cFirstName, cLastName, count(distinct eID) as "total episodes"
from charactr
join says on charactr.cID = says.cID
group by cFirstName, cLastName
having count(distinct eID) >= 30
