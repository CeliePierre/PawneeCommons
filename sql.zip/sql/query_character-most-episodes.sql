-- Most popular characters (appears in most episodes)

select rank() over (order by count(distinct eID) desc) as "rank", 
	cFirstName, cLastName, count(distinct eID) as "total episodes"
from charactr
join says on charactr.cID = says.cID
group by cFirstName, cLastName;
