-- Character with the most lines, ranked

select rank() over (order by count(distinct lID) desc) as "rank", 
	cFirstName, cLastName, count(distinct lID) as "total lines"
from charactr
join says on charactr.cID = says.cID
group by cFirstName, cLastName;
